function Navbar() {
  return (
    <>
      <div className="nav">
          <h4>HOME</h4>
          <h4>ABOUT</h4>
          <h4>ITEMS</h4>
      </div>
    </>
  );
}

export default Navbar;
