import { Link } from "react-router-dom";
function About() {
  return (
    <>
      <main>
        <h1>About Page</h1>
        <Link to="/">back</Link>
      </main>
    </>
  );
}

export default About;
