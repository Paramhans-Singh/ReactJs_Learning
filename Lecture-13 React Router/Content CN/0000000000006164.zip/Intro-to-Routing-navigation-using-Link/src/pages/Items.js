import { Link } from "react-router-dom";

function Items() {
  return (
    <>
      <main>
        <h1>Items Page</h1>
        <Link to="/">back</Link>
      </main>
    </>
  );
}

export default Items;
