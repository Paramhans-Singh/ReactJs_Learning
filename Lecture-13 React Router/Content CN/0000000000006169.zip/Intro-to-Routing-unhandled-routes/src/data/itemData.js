export const ITEMS = [
  { id: "i-1", title: "Item1", detail: "Item-1-Details" },
  { id: "i-2", title: "Item2", detail: "Item-2-Details" },
  { id: "i-3", title: "Item3", detail: "Item-2-Details" },
];
